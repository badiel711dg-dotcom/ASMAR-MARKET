import { useState } from 'react';
import { Mail, Lock, User, Store, ChevronRight } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';

export function AuthPage({ mode }: { mode: 'signin' | 'signup' }) {
  const { signIn, signUp } = useAuth();
  const { navigate } = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [role, setRole] = useState('customer');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const isSignUp = mode === 'signup';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    if (isSignUp) {
      const { error } = await signUp(email, password, displayName, role);
      if (error) setError(error);
      else navigate('/');
    } else {
      const { error } = await signIn(email, password);
      if (error) setError(error);
      else navigate('/');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-[calc(100vh-5rem)] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="font-serif text-3xl font-semibold text-mocha">
            {isSignUp ? 'Join MODER ONE' : 'Welcome Back'}
          </h1>
          <p className="text-sm text-taupe mt-2">
            {isSignUp ? 'Create your account to begin' : 'Sign in to your account'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="card-luxury p-8 space-y-5">
          {isSignUp && (
            <>
              <div>
                <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Full Name</label>
                <div className="relative">
                  <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-taupe" />
                  <input
                    required
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="input-luxury pl-10"
                    placeholder="Your name"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Account Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRole('customer')}
                    className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-sm border transition-all ${
                      role === 'customer' ? 'border-antique-gold bg-champagne/15 text-mocha' : 'border-champagne/30 text-taupe hover:border-champagne'
                    }`}
                  >
                    <User size={16} /> Customer
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('merchant')}
                    className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-sm border transition-all ${
                      role === 'merchant' ? 'border-antique-gold bg-champagne/15 text-mocha' : 'border-champagne/30 text-taupe hover:border-champagne'
                    }`}
                  >
                    <Store size={16} /> Merchant
                  </button>
                </div>
              </div>
            </>
          )}
          <div>
            <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Email</label>
            <div className="relative">
              <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-taupe" />
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input-luxury pl-10"
                placeholder="you@example.com"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Password</label>
            <div className="relative">
              <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-taupe" />
              <input
                required
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input-luxury pl-10"
                placeholder="••••••••"
                minLength={6}
              />
            </div>
          </div>

          {error && (
            <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-4 py-2">{error}</p>
          )}

          <button type="submit" disabled={loading} className="btn-primary w-full">
            {loading ? 'Please wait...' : isSignUp ? 'Create Account' : 'Sign In'}
            {!loading && <ChevronRight size={16} />}
          </button>
        </form>

        <p className="text-center text-sm text-taupe mt-6">
          {isSignUp ? 'Already have an account?' : "Don't have an account?"}{' '}
          <button onClick={() => navigate(isSignUp ? '/signin' : '/signup')} className="text-antique-gold hover:text-mocha transition-colors font-medium">
            {isSignUp ? 'Sign In' : 'Sign Up'}
          </button>
        </p>
      </div>
    </div>
  );
}
