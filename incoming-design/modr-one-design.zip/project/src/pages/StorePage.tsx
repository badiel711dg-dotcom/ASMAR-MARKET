import { useEffect, useState } from 'react';
import { Store, Heart, ChevronLeft } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import type { Merchant, Product, MerchantWithCounts } from '@/types';
import { ProductCard } from '@/components/ProductCard';
import { MerchantCard } from '@/components/MerchantCard';

type Props = {
  slug?: string;
};

export function StorePage({ slug }: Props) {
  const { session } = useAuth();
  const { navigate } = useRouter();
  const [merchants, setMerchants] = useState<MerchantWithCounts[]>([]);
  const [merchant, setMerchant] = useState<Merchant | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFollowing, setIsFollowing] = useState(false);

  // If no slug, show all stores
  useEffect(() => {
    if (!slug) {
      (async () => {
        const { data: merchs } = await supabase
          .from('merchants')
          .select('*')
          .eq('is_approved', true);
        const merchsWithCounts = await Promise.all(
          ((merchs as Merchant[]) ?? []).map(async (m) => {
            const { count } = await supabase
              .from('products')
              .select('*', { count: 'exact', head: true })
              .eq('merchant_id', m.id)
              .eq('is_active', true);
            return { ...m, product_count: count ?? 0 } as MerchantWithCounts;
          })
        );
        setMerchants(merchsWithCounts);
        setLoading(false);
      })();
    }
  }, [slug]);

  // Single store
  useEffect(() => {
    if (!slug) return;
    setLoading(true);
    (async () => {
      const { data: merch } = await supabase
        .from('merchants')
        .select('*')
        .eq('slug', slug)
        .maybeSingle();
      if (!merch) { setLoading(false); return; }
      setMerchant(merch as Merchant);

      const { data: prods } = await supabase
        .from('products')
        .select('*')
        .eq('merchant_id', (merch as Merchant).id)
        .eq('is_active', true);
      setProducts((prods as Product[]) ?? []);

      if (session) {
        const { data: follow } = await supabase
          .from('merchant_follows')
          .select('id')
          .eq('user_id', session.user.id)
          .eq('merchant_id', (merch as Merchant).id)
          .maybeSingle();
        setIsFollowing(!!follow);
      }
      setLoading(false);
    })();
  }, [slug, session]);

  const toggleFollow = async () => {
    if (!session || !merchant) { navigate('/signin'); return; }
    if (isFollowing) {
      await supabase.from('merchant_follows').delete()
        .eq('user_id', session.user.id).eq('merchant_id', merchant.id);
      setIsFollowing(false);
    } else {
      await supabase.from('merchant_follows').insert({
        user_id: session.user.id,
        merchant_id: merchant.id,
      });
      setIsFollowing(true);
    }
  };

  // All stores view
  if (!slug) {
    return (
      <div className="pb-20 lg:pb-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="section-heading">Boutique Stores</h1>
          <div className="section-divider mt-2 w-24" />
          <p className="text-sm text-taupe mt-3 mb-8">Discover unique collections from our curated merchants.</p>
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="card-luxury overflow-hidden">
                  <div className="h-32 skeleton" />
                  <div className="p-4 flex gap-3">
                    <div className="w-12 h-12 rounded-full skeleton" />
                    <div className="flex-1 space-y-2"><div className="h-4 w-32 skeleton rounded" /><div className="h-3 w-48 skeleton rounded" /></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {merchants.map((m) => (
                <MerchantCard key={m.id} merchant={m} />
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Single store view
  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="h-48 skeleton rounded-xl mb-8" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="card-luxury overflow-hidden">
              <div className="aspect-[4/5] skeleton" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!merchant) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <Store size={48} className="text-champagne mx-auto mb-4" />
        <p className="text-mocha font-medium text-lg">Store not found</p>
        <button onClick={() => navigate('/stores')} className="btn-primary mt-4">Browse All Stores</button>
      </div>
    );
  }

  const theme = merchant.theme || { primary: '#D6BD91', accent: '#B89A68' };

  return (
    <div className="pb-20 lg:pb-0">
      {/* Cover */}
      <div className="relative h-48 sm:h-64 overflow-hidden bg-ivory">
        {merchant.cover_url && (
          <img src={merchant.cover_url} alt={merchant.name} className="w-full h-full object-cover" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-deep-brown/50 to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Store header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 -mt-12 relative z-10">
          <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden border-4 border-ivory bg-ivory flex-shrink-0">
            {merchant.logo_url && <img src={merchant.logo_url} alt={merchant.name} className="w-full h-full object-cover" />}
          </div>
          <div className="flex-1 pt-2">
            <h1 className="font-serif text-2xl sm:text-3xl font-semibold text-mocha">{merchant.name}</h1>
            <p className="text-sm text-taupe mt-1 max-w-xl">{merchant.description}</p>
          </div>
          <button
            onClick={toggleFollow}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${
              isFollowing
                ? 'bg-dusty-rose/30 text-mocha border border-dusty-rose-dark/30'
                : 'bg-champagne text-deep-brown border border-antique-gold/30 hover:bg-champagne-dark'
            }`}
          >
            <Heart size={16} className={isFollowing ? 'fill-dusty-rose-dark text-dusty-rose-dark' : ''} />
            {isFollowing ? 'Following' : 'Follow Store'}
          </button>
        </div>

        <button onClick={() => navigate('/stores')} className="text-sm text-taupe hover:text-antique-gold transition-colors flex items-center gap-1 mt-6 mb-4">
          <ChevronLeft size={14} /> All Stores
        </button>

        {/* Products */}
        <div className="mb-4">
          <h2 className="section-heading">Products</h2>
          <div className="section-divider mt-2 w-24" />
        </div>

        {products.length === 0 ? (
          <p className="text-sm text-taupe py-16 text-center">This store has no products yet.</p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} merchantName={merchant.name} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
