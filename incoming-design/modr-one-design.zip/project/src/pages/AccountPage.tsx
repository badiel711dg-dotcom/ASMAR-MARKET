import { useEffect, useState } from 'react';
import { Package, User as UserIcon, LogOut, Settings, Heart, ShoppingBag, Store, BarChart3, Box, TrendingUp, CheckCircle, Clock, Truck } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { supabase } from '@/lib/supabase';
import { formatPrice, formatDate } from '@/lib/utils';
import type { Order, OrderItem, Product, Merchant } from '@/types';

type Tab = 'orders' | 'profile' | 'wishlist' | 'products' | 'store' | 'overview';

export function AccountPage() {
  const { session, profile, signOut, refreshProfile } = useAuth();
  const { navigate } = useRouter();
  const [tab, setTab] = useState<Tab>('orders');
  const [orders, setOrders] = useState<(Order & { order_items?: OrderItem[] })[]>([]);
  const [merchantProducts, setMerchantProducts] = useState<Product[]>([]);
  const [merchant, setMerchant] = useState<Merchant | null>(null);
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState(profile?.display_name ?? '');
  const [phone, setPhone] = useState(profile?.phone ?? '');
  const [bio, setBio] = useState(profile?.bio ?? '');

  useEffect(() => {
    if (!session) return;
    (async () => {
      const { data: ords } = await supabase
        .from('orders')
        .select('*, order_items(*)')
        .eq('user_id', session.user.id)
        .order('created_at', { ascending: false });
      setOrders((ords as (Order & { order_items?: OrderItem[] })[]) ?? []);

      if (profile?.role === 'merchant') {
        const { data: merch } = await supabase
          .from('merchants')
          .select('*')
          .eq('owner_id', session.user.id)
          .maybeSingle();
        if (merch) {
          setMerchant(merch as Merchant);
          const { data: prods } = await supabase
            .from('products')
            .select('*')
            .eq('merchant_id', (merch as Merchant).id)
            .order('created_at', { ascending: false });
          setMerchantProducts((prods as Product[]) ?? []);
        }
      }
    })();
  }, [session, profile]);

  useEffect(() => {
    if (profile?.role === 'merchant') setTab('overview');
    else if (profile?.role === 'owner') setTab('overview');
  }, [profile]);

  if (!session) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <p className="text-mocha font-medium text-lg">Please sign in to access your account</p>
        <button onClick={() => navigate('/signin')} className="btn-primary mt-4">Sign In</button>
      </div>
    );
  }

  const isMerchant = profile?.role === 'merchant';
  const isOwner = profile?.role === 'owner';

  const handleSaveProfile = async () => {
    await supabase.from('profiles').update({ display_name: displayName, phone, bio }).eq('id', session.user.id);
    await refreshProfile();
    setEditing(false);
  };

  const statusIcon = (status: string) => {
    switch (status) {
      case 'delivered': return <CheckCircle size={14} className="text-green-600" />;
      case 'shipped': return <Truck size={14} className="text-blue-600" />;
      case 'confirmed': return <Package size={14} className="text-antique-gold" />;
      default: return <Clock size={14} className="text-taupe" />;
    }
  };

  const customerTabs: { id: Tab; label: string; icon: typeof Package }[] = [
    { id: 'orders', label: 'My Orders', icon: Package },
    { id: 'profile', label: 'Profile', icon: UserIcon },
    { id: 'wishlist', label: 'Wishlist', icon: Heart },
  ];

  const merchantTabs: { id: Tab; label: string; icon: typeof Package }[] = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'products', label: 'Products', icon: Box },
    { id: 'orders', label: 'Orders', icon: Package },
    { id: 'store', label: 'Store Settings', icon: Store },
    { id: 'profile', label: 'Profile', icon: UserIcon },
  ];

  const tabs = isMerchant ? merchantTabs : customerTabs;

  return (
    <div className="pb-20 lg:pb-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="section-heading">{isMerchant ? 'Merchant Dashboard' : isOwner ? 'Owner Dashboard' : 'My Account'}</h1>
          <div className="section-divider mt-2 w-24" />
          <p className="text-sm text-taupe mt-2">Welcome, {profile?.display_name || session.user.email}</p>
        </div>
        <button onClick={() => signOut().then(() => navigate('/'))} className="btn-outline text-sm self-start">
          <LogOut size={14} /> Sign Out
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Sidebar */}
        <aside className="lg:w-56 flex-shrink-0">
          <div className="flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible scrollbar-hide">
            {tabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                  tab === t.id ? 'bg-champagne/15 text-mocha border border-champagne/30' : 'text-mocha/70 hover:bg-dusty-rose/20'
                }`}
              >
                <t.icon size={16} className="text-antique-gold" /> {t.label}
              </button>
            ))}
          </div>
        </aside>

        {/* Content */}
        <div className="flex-1 min-w-0">
          {/* Orders */}
          {tab === 'orders' && (
            <div className="space-y-4">
              <h2 className="font-serif text-xl font-medium text-mocha">Order History</h2>
              {orders.length === 0 ? (
                <div className="card-luxury p-12 text-center">
                  <Package size={36} className="text-champagne mx-auto mb-3" />
                  <p className="text-mocha font-medium">No orders yet</p>
                  <button onClick={() => navigate('/')} className="btn-primary mt-4">Start Shopping</button>
                </div>
              ) : (
                orders.map((order) => (
                  <div key={order.id} className="card-luxury p-5">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="text-sm font-medium text-mocha">Order #{order.id.slice(0, 8)}</p>
                        <p className="text-xs text-taupe">{formatDate(order.created_at)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {statusIcon(order.status)}
                        <span className="text-xs font-medium text-mocha capitalize">{order.status}</span>
                      </div>
                    </div>
                    <div className="space-y-2 border-t border-champagne/10 pt-3">
                      {order.order_items?.map((item) => (
                        <div key={item.id} className="flex items-center gap-3 text-sm">
                          <div className="w-10 h-12 rounded overflow-hidden bg-ivory border border-champagne/20 flex-shrink-0">
                            {item.image_url && <img src={item.image_url} alt="" className="w-full h-full object-cover" />}
                          </div>
                          <span className="flex-1 text-mocha">{item.product_name}</span>
                          <span className="text-taupe">×{item.quantity}</span>
                          <span className="text-mocha font-medium">{formatPrice(item.price * item.quantity)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between items-center pt-3 border-t border-champagne/10 mt-3">
                      <span className="text-sm text-taupe">Total</span>
                      <span className="font-serif text-lg font-semibold text-mocha">{formatPrice(order.total)}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* Merchant Overview */}
          {tab === 'overview' && isMerchant && (
            <div className="space-y-6">
              <h2 className="font-serif text-xl font-medium text-mocha">Store Overview</h2>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Products', value: merchantProducts.length, icon: Box },
                  { label: 'Active Products', value: merchantProducts.filter((p) => p.is_active).length, icon: TrendingUp },
                  { label: 'Featured', value: merchantProducts.filter((p) => p.is_featured).length, icon: StarIcon },
                  { label: 'Total Stock', value: merchantProducts.reduce((s, p) => s + p.stock, 0), icon: Package },
                ].map((stat) => (
                  <div key={stat.label} className="card-luxury p-5">
                    <stat.icon size={20} className="text-antique-gold mb-2" />
                    <p className="font-serif text-2xl font-semibold text-mocha">{stat.value}</p>
                    <p className="text-xs text-taupe mt-1">{stat.label}</p>
                  </div>
                ))}
              </div>
              {merchant && (
                <div className="card-luxury p-6">
                  <h3 className="font-serif text-lg font-medium text-mocha mb-3">Store Status</h3>
                  <div className="flex items-center gap-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${merchant.is_approved ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                      {merchant.is_approved ? 'Approved' : 'Pending Approval'}
                    </span>
                    <span className="text-sm text-taupe">{merchant.name}</span>
                  </div>
                  <button onClick={() => navigate(`/stores/${merchant.slug}`)} className="btn-outline mt-4 text-sm">
                    View Store
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Merchant Products */}
          {tab === 'products' && isMerchant && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-serif text-xl font-medium text-mocha">Product Management</h2>
                <span className="text-sm text-taupe">{merchantProducts.length} products</span>
              </div>
              {merchantProducts.length === 0 ? (
                <div className="card-luxury p-12 text-center">
                  <Box size={36} className="text-champagne mx-auto mb-3" />
                  <p className="text-mocha font-medium">No products yet</p>
                  <p className="text-sm text-taupe mt-1">Products are managed via the database in this demo.</p>
                </div>
              ) : (
                <div className="card-luxury overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-dusty-rose/20">
                      <tr className="text-left text-xs text-taupe uppercase tracking-wider">
                        <th className="px-4 py-3 font-medium">Product</th>
                        <th className="px-4 py-3 font-medium hidden sm:table-cell">Price</th>
                        <th className="px-4 py-3 font-medium hidden sm:table-cell">Stock</th>
                        <th className="px-4 py-3 font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {merchantProducts.map((p) => (
                        <tr key={p.id} className="border-t border-champagne/10 hover:bg-dusty-rose/10">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-12 rounded overflow-hidden bg-ivory border border-champagne/20 flex-shrink-0">
                                {p.images?.[0] && <img src={p.images[0]} alt="" className="w-full h-full object-cover" />}
                              </div>
                              <span className="text-mocha font-medium line-clamp-1">{p.name}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-mocha hidden sm:table-cell">{formatPrice(p.price)}</td>
                          <td className="px-4 py-3 text-mocha hidden sm:table-cell">{p.stock}</td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2 py-1 rounded-full ${p.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                              {p.is_active ? 'Active' : 'Inactive'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Store Settings */}
          {tab === 'store' && isMerchant && merchant && (
            <div className="space-y-6">
              <h2 className="font-serif text-xl font-medium text-mocha">Store Settings</h2>
              <div className="card-luxury p-6 space-y-4">
                <div>
                  <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Store Name</label>
                  <input className="input-luxury" defaultValue={merchant.name} readOnly />
                </div>
                <div>
                  <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Description</label>
                  <textarea className="input-luxury resize-none" rows={3} defaultValue={merchant.description ?? ''} readOnly />
                </div>
                <div>
                  <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Logo URL</label>
                  <input className="input-luxury" defaultValue={merchant.logo_url ?? ''} readOnly />
                </div>
                <div>
                  <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Theme Colors</label>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full border border-champagne/30" style={{ background: merchant.theme?.primary }} />
                      <span className="text-sm text-mocha">Primary</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full border border-champagne/30" style={{ background: merchant.theme?.accent }} />
                      <span className="text-sm text-mocha">Accent</span>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-taupe">Store settings are read-only in this demo.</p>
              </div>
            </div>
          )}

          {/* Wishlist */}
          {tab === 'wishlist' && (
            <div>
              <h2 className="font-serif text-xl font-medium text-mocha mb-4">Saved Items</h2>
              <div className="card-luxury p-12 text-center">
                <Heart size={36} className="text-champagne mx-auto mb-3" />
                <p className="text-mocha font-medium">View your wishlist</p>
                <button onClick={() => navigate('/wishlist')} className="btn-primary mt-4">Go to Wishlist</button>
              </div>
            </div>
          )}

          {/* Profile */}
          {tab === 'profile' && (
            <div className="space-y-6">
              <h2 className="font-serif text-xl font-medium text-mocha">Profile Settings</h2>
              <div className="card-luxury p-6 space-y-4 max-w-lg">
                <div>
                  <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Email</label>
                  <input className="input-luxury" value={session.user.email ?? ''} readOnly />
                </div>
                <div>
                  <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Display Name</label>
                  <input
                    className="input-luxury"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    disabled={!editing}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Phone</label>
                  <input
                    className="input-luxury"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    disabled={!editing}
                    placeholder="Optional"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Bio</label>
                  <textarea
                    className="input-luxury resize-none"
                    rows={3}
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    disabled={!editing}
                    placeholder="Tell us about yourself"
                  />
                </div>
                {editing ? (
                  <div className="flex gap-3">
                    <button onClick={handleSaveProfile} className="btn-primary">Save Changes</button>
                    <button onClick={() => setEditing(false)} className="btn-outline">Cancel</button>
                  </div>
                ) : (
                  <button onClick={() => setEditing(true)} className="btn-outline">
                    <Settings size={14} /> Edit Profile
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StarIcon({ size = 20, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
    </svg>
  );
}
