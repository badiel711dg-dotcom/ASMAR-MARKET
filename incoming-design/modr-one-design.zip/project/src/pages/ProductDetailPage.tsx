import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, ShoppingBag, Truck, RotateCcw, ShieldCheck, Store } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useShop } from '@/context/ShopContext';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import type { Product, Merchant, Review } from '@/types';
import { formatPrice } from '@/lib/utils';
import { StarRating } from '@/components/StarRating';
import { WishlistButton } from '@/components/WishlistButton';
import { ProductCard } from '@/components/ProductCard';

type Props = {
  productId: string;
};

export function ProductDetailPage({ productId }: Props) {
  const { addToCart } = useShop();
  const { session } = useAuth();
  const { navigate } = useRouter();
  const [product, setProduct] = useState<Product | null>(null);
  const [merchant, setMerchant] = useState<Merchant | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [related, setRelated] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeImage, setActiveImage] = useState(0);
  const [qty, setQty] = useState(1);
  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>({});
  const [adding, setAdding] = useState(false);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' });
  const [showReviewForm, setShowReviewForm] = useState(false);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data: prod } = await supabase
        .from('products')
        .select('*')
        .eq('id', productId)
        .maybeSingle();
      if (!prod) { setLoading(false); return; }
      setProduct(prod as Product);

      const [merchRes, revRes] = await Promise.all([
        supabase.from('merchants').select('*').eq('id', (prod as Product).merchant_id).maybeSingle(),
        supabase.from('reviews').select('*, profiles(display_name)').eq('product_id', productId).order('created_at', { ascending: false }),
      ]);
      setMerchant((merchRes.data as Merchant) ?? null);
      setReviews((revRes.data as Review[]) ?? []);

      if ((prod as Product).category_id) {
        const { data: rel } = await supabase
          .from('products')
          .select('*')
          .eq('category_id', (prod as Product).category_id)
          .neq('id', productId)
          .limit(4);
        setRelated((rel as Product[]) ?? []);
      }
      setLoading(false);
    })();
  }, [productId]);

  // Initialize variant selections
  useEffect(() => {
    if (product?.variants?.length) {
      const init: Record<string, string> = {};
      product.variants.forEach((v) => {
        if (v.options.length > 0) init[v.name] = v.options[0];
      });
      setSelectedVariants(init);
    }
  }, [product]);

  const handleAddToCart = () => {
    if (!session) { navigate('/signin'); return; }
    if (!product || product.stock <= 0) return;
    setAdding(true);
    addToCart(product.id, qty, Object.keys(selectedVariants).length > 0 ? selectedVariants : null).finally(() => {
      setTimeout(() => setAdding(false), 600);
    });
  };

  const submitReview = async () => {
    if (!session || !product) return;
    const { data } = await supabase
      .from('reviews')
      .insert({
        product_id: product.id,
        user_id: session.user.id,
        rating: reviewForm.rating,
        comment: reviewForm.comment,
      })
      .select('*, profiles(display_name)')
      .maybeSingle();
    if (data) {
      setReviews([data as Review, ...reviews]);
      setReviewForm({ rating: 5, comment: '' });
      setShowReviewForm(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="aspect-[4/5] skeleton rounded-xl" />
          <div className="space-y-4">
            <div className="h-6 w-32 skeleton rounded" />
            <div className="h-8 w-full skeleton rounded" />
            <div className="h-6 w-24 skeleton rounded" />
            <div className="h-32 w-full skeleton rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <p className="text-mocha font-medium text-lg">Product not found</p>
        <button onClick={() => navigate('/')} className="btn-primary mt-4">Return Home</button>
      </div>
    );
  }

  const images = product.images ?? [];
  const hasDiscount = product.compare_at_price && product.compare_at_price > product.price;

  return (
    <div className="pb-20 lg:pb-0">
      {/* Breadcrumb */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <button onClick={() => navigate('/')} className="text-sm text-taupe hover:text-antique-gold transition-colors flex items-center gap-1">
          <ChevronLeft size={14} /> Back to Home
        </button>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Gallery */}
          <div className="space-y-4">
            <div className="aspect-[4/5] rounded-xl overflow-hidden bg-ivory border border-champagne/20 relative">
              {images[activeImage] && (
                <img src={images[activeImage]} alt={product.name} className="w-full h-full object-cover" />
              )}
              <div className="absolute top-4 right-4">
                <WishlistButton productId={product.id} likeCount={product.like_count} />
              </div>
            </div>
            {images.length > 1 && (
              <div className="flex gap-3 overflow-x-auto scrollbar-hide">
                {images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-all
                      ${activeImage === i ? 'border-antique-gold' : 'border-champagne/20 hover:border-champagne'}`}
                  >
                    <img src={img} alt={`${product.name} ${i + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="space-y-6">
            <div>
              {merchant && (
                <button
                  onClick={() => navigate(`/stores/${merchant.slug}`)}
                  className="text-xs tracking-wider uppercase text-antique-gold hover:text-mocha transition-colors flex items-center gap-1.5"
                >
                  <Store size={12} /> {merchant.name}
                </button>
              )}
              <h1 className="font-serif text-2xl sm:text-3xl font-medium text-mocha mt-2">{product.name}</h1>
              <div className="flex items-center gap-3 mt-3">
                <StarRating rating={product.rating_avg} count={product.review_count} size={16} />
              </div>
            </div>

            <div className="flex items-baseline gap-3">
              <span className="font-serif text-3xl font-semibold text-mocha">{formatPrice(product.price)}</span>
              {hasDiscount && (
                <span className="text-lg text-taupe line-through">{formatPrice(product.compare_at_price as number)}</span>
              )}
            </div>

            {product.description && (
              <p className="text-sm text-mocha/70 leading-relaxed">{product.description}</p>
            )}

            {/* Variants */}
            {product.variants?.length > 0 && (
              <div className="space-y-4">
                {product.variants.map((variant) => (
                  <div key={variant.name}>
                    <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">
                      {variant.name}
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {variant.options.map((opt) => (
                        <button
                          key={opt}
                          onClick={() => setSelectedVariants({ ...selectedVariants, [variant.name]: opt })}
                          className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all
                            ${selectedVariants[variant.name] === opt
                              ? 'border-antique-gold bg-champagne/15 text-mocha'
                              : 'border-champagne/30 bg-porcelain text-mocha hover:border-champagne'
                            }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Quantity + Add to cart */}
            <div className="flex items-center gap-4 pt-2">
              <div className="flex items-center border border-champagne/30 rounded-lg overflow-hidden">
                <button
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="px-3 py-3 text-mocha hover:bg-champagne/15 transition-colors"
                >
                  <ChevronLeft size={16} />
                </button>
                <span className="px-4 text-sm font-medium text-mocha">{qty}</span>
                <button
                  onClick={() => setQty(qty + 1)}
                  className="px-3 py-3 text-mocha hover:bg-champagne/15 transition-colors"
                >
                  <ChevronRight size={16} />
                </button>
              </div>
              <button
                onClick={handleAddToCart}
                disabled={product.stock <= 0 || adding}
                className="btn-primary flex-1 py-3.5 text-sm tracking-wider uppercase"
              >
                <ShoppingBag size={16} />
                {product.stock <= 0 ? 'Sold Out' : adding ? 'Adding...' : 'Add to Bag'}
              </button>
            </div>

            {/* Stock */}
            <p className="text-xs text-taupe">
              {product.stock > 0
                ? product.stock <= 5
                  ? `Only ${product.stock} left in stock`
                  : 'In stock — ready to ship'
                : 'Currently unavailable'}
            </p>

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-champagne/20">
              {[
                { icon: Truck, label: 'Free shipping over $200' },
                { icon: RotateCcw, label: '30-day returns' },
                { icon: ShieldCheck, label: 'Authenticity guaranteed' },
              ].map((item) => (
                <div key={item.label} className="flex flex-col items-center text-center gap-1.5">
                  <item.icon size={20} className="text-antique-gold" />
                  <span className="text-[11px] text-taupe leading-tight">{item.label}</span>
                </div>
              ))}
            </div>

            {/* Merchant info */}
            {merchant && (
              <div className="flex items-center gap-4 p-4 rounded-xl border border-champagne/20 bg-porcelain/50">
                <div className="w-14 h-14 rounded-full overflow-hidden border border-champagne/30 flex-shrink-0">
                  {merchant.logo_url && <img src={merchant.logo_url} alt={merchant.name} className="w-full h-full object-cover" />}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-serif text-sm font-medium text-mocha">{merchant.name}</h3>
                  <p className="text-xs text-taupe line-clamp-1">{merchant.description}</p>
                </div>
                <button
                  onClick={() => navigate(`/stores/${merchant.slug}`)}
                  className="text-xs text-antique-gold hover:text-mocha transition-colors whitespace-nowrap"
                >
                  Visit Store
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Reviews section */}
        <div className="mt-16 max-w-3xl">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="section-heading">Reviews</h2>
              <div className="section-divider mt-2 w-24" />
            </div>
            {session && (
              <button onClick={() => setShowReviewForm(!showReviewForm)} className="btn-outline text-xs">
                Write a Review
              </button>
            )}
          </div>

          {showReviewForm && (
            <div className="card-luxury p-6 mb-6 space-y-4 animate-slide-up">
              <div>
                <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Rating</label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setReviewForm({ ...reviewForm, rating: star })}
                      className="text-2xl transition-transform hover:scale-110"
                    >
                      <span className={star <= reviewForm.rating ? 'text-champagne' : 'text-champagne/30'}>★</span>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Your Review</label>
                <textarea
                  value={reviewForm.comment}
                  onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })}
                  rows={4}
                  placeholder="Share your experience with this product..."
                  className="input-luxury resize-none"
                />
              </div>
              <button onClick={submitReview} className="btn-primary">Submit Review</button>
            </div>
          )}

          {reviews.length === 0 ? (
            <p className="text-sm text-taupe py-8 text-center">No reviews yet. Be the first to share your experience.</p>
          ) : (
            <div className="space-y-4">
              {reviews.map((rev) => (
                <div key={rev.id} className="card-luxury p-5">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-champagne/20 flex items-center justify-center text-sm font-medium text-mocha">
                        {(rev.profiles?.display_name || 'A')[0]?.toUpperCase()}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-mocha">{rev.profiles?.display_name || 'Anonymous'}</p>
                        {rev.is_verified_purchase && (
                          <span className="text-[10px] text-antique-gold flex items-center gap-1">
                            <ShieldCheck size={10} /> Verified Purchase
                          </span>
                        )}
                      </div>
                    </div>
                    <StarRating rating={rev.rating} showValue={false} />
                  </div>
                  {rev.comment && <p className="text-sm text-mocha/70 mt-2">{rev.comment}</p>}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Related products */}
        {related.length > 0 && (
          <div className="mt-16">
            <div className="mb-8">
              <h2 className="section-heading">You May Also Like</h2>
              <div className="section-divider mt-2 w-24" />
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} merchantName={merchant?.name} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
