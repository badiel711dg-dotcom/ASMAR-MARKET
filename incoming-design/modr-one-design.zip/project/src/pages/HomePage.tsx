import { useEffect, useState } from 'react';
import { ArrowRight, Truck, ShieldCheck, Headphones, RotateCcw } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useRouter } from '@/context/RouterContext';
import type { ProductWithMerchant, Category, Merchant } from '@/types';
import { ProductCard } from '@/components/ProductCard';
import { CategoryCard } from '@/components/CategoryCard';
import { MerchantCard } from '@/components/MerchantCard';

export function HomePage() {
  const { navigate } = useRouter();
  const [featured, setFeatured] = useState<ProductWithMerchant[]>([]);
  [/* state */];
  const [newArrivals, setNewArrivals] = useState<ProductWithMerchant[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [featRes, newRes, catRes, merchRes] = await Promise.all([
        supabase.from('products').select('*, merchants(*)').eq('is_featured', true).limit(8),
        supabase.from('products').select('*, merchants(*)').eq('is_new', true).limit(8),
        supabase.from('categories').select('*').order('sort_order'),
        supabase.from('merchants').select('*').eq('is_approved', true).limit(6),
      ]);
      setFeatured((featRes.data as ProductWithMerchant[]) ?? []);
      setNewArrivals((newRes.data as ProductWithMerchant[]) ?? []);
      setCategories((catRes.data as Category[]) ?? []);
      setMerchants((merchRes.data as Merchant[]) ?? []);
      setLoading(false);
    })();
  }, []);

  return (
    <div className="pb-20 lg:pb-0">
      {/* Hero */}
      <section className="relative h-[55vh] min-h-[400px] max-h-[600px] overflow-hidden">
        <img
          src="https://images.pexels.com/photos/33722978/pexels-photo-33722978.jpeg?auto=compress&cs=tinysrgb&h=1200&w=2000"
          alt="MODER ONE Collection"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-deep-brown/70 via-deep-brown/20 to-deep-brown/30" />
        <div className="relative h-full flex flex-col items-center justify-center text-center px-6">
          <p className="text-xs tracking-[0.3em] uppercase text-champagne mb-3 animate-fade-in-down">
            The Autumn Collection
          </p>
          <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-semibold text-porcelain max-w-2xl animate-fade-in-up">
            Discover Your Style
          </h1>
          <p className="mt-4 text-sm sm:text-base text-porcelain/70 max-w-md animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            Curated luxury from independent merchants around the world.
          </p>
          <button
            onClick={() => navigate('/categories')}
            className="mt-8 inline-flex items-center gap-2 px-8 py-3.5 rounded-lg bg-champagne text-deep-brown font-medium text-sm tracking-wider uppercase
              border border-antique-gold/40 hover:bg-champagne-dark hover:shadow-luxury-lg transition-all duration-300 animate-fade-in-up"
            style={{ animationDelay: '0.4s' }}
          >
            Explore Collection <ArrowRight size={16} />
          </button>
        </div>
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="section-heading">Curated Categories</h2>
              <div className="section-divider mt-2 w-24" />
            </div>
            <button onClick={() => navigate('/categories')} className="text-sm text-antique-gold hover:text-mocha transition-colors flex items-center gap-1">
              View All <ArrowRight size={14} />
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {categories.slice(0, 6).map((cat) => (
              <CategoryCard key={cat.id} category={cat} />
            ))}
          </div>
        </section>
      )}

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="section-heading">Featured Pieces</h2>
            <div className="section-divider mt-2 w-24" />
          </div>
        </div>
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="card-luxury overflow-hidden">
                <div className="aspect-[4/5] skeleton" />
                <div className="p-4 space-y-2">
                  <div className="h-3 w-20 skeleton rounded" />
                  <div className="h-4 w-full skeleton rounded" />
                  <div className="h-4 w-1/2 skeleton rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {featured.map((p) => (
              <ProductCard key={p.id} product={p} merchantName={p.merchants?.name} />
            ))}
          </div>
        )}
      </section>

      {/* Editorial Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="relative rounded-2xl overflow-hidden h-[300px] sm:h-[400px]">
          <img
            src="https://images.pexels.com/photos/38520940/pexels-photo-38520940.jpeg?auto=compress&cs=tinysrgb&h=800&w=1600"
            alt="Editorial"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-deep-brown/60 to-transparent" />
          <div className="absolute inset-0 flex flex-col justify-center px-8 sm:px-16 max-w-lg">
            <p className="text-xs tracking-[0.3em] uppercase text-champagne mb-3">Editorial</p>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-porcelain">
              The Art of Living Well
            </h2>
            <p className="mt-3 text-sm text-porcelain/70 max-w-sm">
              Explore our lifestyle edit — where fashion, fragrance, and design converge.
            </p>
            <button
              onClick={() => navigate('/categories')}
              className="mt-6 self-start inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-porcelain/90 text-mocha font-medium text-sm
                hover:bg-porcelain transition-all"
            >
              Discover More <ArrowRight size={14} />
            </button>
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="section-heading">New Arrivals</h2>
            <div className="section-divider mt-2 w-24" />
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {newArrivals.map((p) => (
            <ProductCard key={p.id} product={p} merchantName={p.merchants?.name} />
          ))}
        </div>
      </section>

      {/* Featured Stores */}
      {merchants.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="section-heading">Featured Boutiques</h2>
              <div className="section-divider mt-2 w-24" />
            </div>
            <button onClick={() => navigate('/stores')} className="text-sm text-antique-gold hover:text-mocha transition-colors flex items-center gap-1">
              All Stores <ArrowRight size={14} />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {merchants.map((m) => (
              <MerchantCard key={m.id} merchant={m} />
            ))}
          </div>
        </section>
      )}

      {/* Trust bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { icon: Truck, title: 'Complimentary Shipping', desc: 'On all orders over $200' },
            { icon: ShieldCheck, title: 'Authenticity Guaranteed', desc: 'Every item verified' },
            { icon: RotateCcw, title: 'Easy Returns', desc: '30-day return policy' },
            { icon: Headphones, title: 'Dedicated Support', desc: 'Personal concierge service' },
          ].map((item) => (
            <div key={item.title} className="text-center p-6 rounded-xl border border-champagne/20 bg-porcelain/50">
              <item.icon size={28} className="mx-auto text-antique-gold mb-3" />
              <h3 className="font-serif text-sm font-medium text-mocha">{item.title}</h3>
              <p className="text-xs text-taupe mt-1">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
