import { useEffect, useState, useMemo } from 'react';
import { SlidersHorizontal, X, ChevronDown } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useRouter } from '@/context/RouterContext';
import type { ProductWithMerchant, Category, Merchant } from '@/types';
import { ProductCard } from '@/components/ProductCard';

type Props = {
  categorySlug?: string;
  searchMode?: boolean;
};

export function CategoryPage({ categorySlug, searchMode }: Props) {
  const { navigate } = useRouter();
  const [products, setProducts] = useState<ProductWithMerchant[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(categorySlug ?? null);
  const [selectedMerchant, setSelectedMerchant] = useState<string | null>(null);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [sortBy, setSortBy] = useState('created_at');
  const [showFilters, setShowFilters] = useState(false);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    (async () => {
      const [catRes, merchRes] = await Promise.all([
        supabase.from('categories').select('*').order('sort_order'),
        supabase.from('merchants').select('*').eq('is_approved', true),
      ]);
      setCategories((catRes.data as Category[]) ?? []);
      setMerchants((merchRes.data as Merchant[]) ?? []);
    })();
  }, []);

  useEffect(() => {
    if (categorySlug) {
      const cat = categories.find((c) => c.slug === categorySlug);
      setSelectedCategory(cat?.id ?? null);
    }
  }, [categorySlug, categories]);

  useEffect(() => {
    setLoading(true);
    (async () => {
      let query = supabase.from('products').select('*, merchants(*)').eq('is_active', true);

      if (searchMode && searchQuery) {
        query = query.ilike('name', `%${searchQuery}%`);
      }
      if (selectedCategory) {
        query = query.eq('category_id', selectedCategory);
      }
      if (selectedMerchant) {
        query = query.eq('merchant_id', selectedMerchant);
      }
      query = query.gte('price', priceRange[0]).lte('price', priceRange[1]);

      if (sortBy === 'price_asc') query = query.order('price', { ascending: true });
      else if (sortBy === 'price_desc') query = query.order('price', { ascending: false });
      else if (sortBy === 'rating') query = query.order('rating_avg', { ascending: false });
      else query = query.order('created_at', { ascending: false });

      const { data } = await query.limit(60);
      setProducts((data as ProductWithMerchant[]) ?? []);
      setLoading(false);
    })();
  }, [selectedCategory, selectedMerchant, priceRange, sortBy, searchMode, searchQuery]);

  const categoryName = useMemo(() => {
    if (searchMode) return 'Search Results';
    const cat = categories.find((c) => c.slug === categorySlug);
    return cat?.name ?? 'All Products';
  }, [categories, categorySlug, searchMode]);

  const activeFilterCount = (selectedCategory ? 1 : 0) + (selectedMerchant ? 1 : 0);

  const clearFilters = () => {
    setSelectedCategory(null);
    setSelectedMerchant(null);
    setPriceRange([0, 10000]);
  };

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Categories */}
      <div>
        <h3 className="text-xs font-medium text-taupe uppercase tracking-wider mb-3">Categories</h3>
        <div className="space-y-1.5">
          <button
            onClick={() => { setSelectedCategory(null); if (categorySlug) navigate('/categories'); }}
            className={`block w-full text-left px-3 py-2 rounded-lg text-sm transition-colors
              ${!selectedCategory ? 'bg-champagne/15 text-mocha font-medium' : 'text-mocha/70 hover:bg-dusty-rose/20'}`}
          >
            All Categories
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => { setSelectedCategory(cat.id); navigate(`/categories/${cat.slug}`); }}
              className={`block w-full text-left px-3 py-2 rounded-lg text-sm transition-colors
                ${selectedCategory === cat.id ? 'bg-champagne/15 text-mocha font-medium' : 'text-mocha/70 hover:bg-dusty-rose/20'}`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Merchants */}
      <div>
        <h3 className="text-xs font-medium text-taupe uppercase tracking-wider mb-3">Stores</h3>
        <div className="space-y-1.5">
          <button
            onClick={() => setSelectedMerchant(null)}
            className={`block w-full text-left px-3 py-2 rounded-lg text-sm transition-colors
              ${!selectedMerchant ? 'bg-champagne/15 text-mocha font-medium' : 'text-mocha/70 hover:bg-dusty-rose/20'}`}
          >
            All Stores
          </button>
          {merchants.map((m) => (
            <button
              key={m.id}
              onClick={() => setSelectedMerchant(m.id)}
              className={`block w-full text-left px-3 py-2 rounded-lg text-sm transition-colors
                ${selectedMerchant === m.id ? 'bg-champagne/15 text-mocha font-medium' : 'text-mocha/70 hover:bg-dusty-rose/20'}`}
            >
              {m.name}
            </button>
          ))}
        </div>
      </div>

      {/* Price range */}
      <div>
        <h3 className="text-xs font-medium text-taupe uppercase tracking-wider mb-3">Price Range</h3>
        <div className="flex items-center gap-2">
          <input
            type="number"
            value={priceRange[0]}
            onChange={(e) => setPriceRange([Number(e.target.value), priceRange[1]])}
            className="input-luxury text-sm py-2"
            placeholder="Min"
          />
          <span className="text-taupe">—</span>
          <input
            type="number"
            value={priceRange[1]}
            onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
            className="input-luxury text-sm py-2"
            placeholder="Max"
          />
        </div>
      </div>

      {activeFilterCount > 0 && (
        <button onClick={clearFilters} className="text-xs text-antique-gold hover:text-mocha transition-colors">
          Clear all filters
        </button>
      )}
    </div>
  );

  return (
    <div className="pb-20 lg:pb-0">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Heading */}
        <div className="mb-8">
          {searchMode && (
            <div className="mb-4">
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products..."
                className="input-luxury max-w-md"
              />
            </div>
          )}
          <h1 className="section-heading">{categoryName}</h1>
          <div className="section-divider mt-2 w-24" />
          <p className="text-sm text-taupe mt-3">{products.length} {products.length === 1 ? 'item' : 'items'}</p>
        </div>

        <div className="flex gap-8">
          {/* Desktop filters */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="sticky top-24">
              <FilterContent />
            </div>
          </aside>

          {/* Products grid */}
          <div className="flex-1">
            {/* Sort + mobile filter toggle */}
            <div className="flex items-center justify-between mb-6">
              <button
                onClick={() => setShowFilters(true)}
                className="lg:hidden flex items-center gap-2 px-4 py-2 rounded-lg border border-champagne/30 text-sm text-mocha"
              >
                <SlidersHorizontal size={16} /> Filters {activeFilterCount > 0 && `(${activeFilterCount})`}
              </button>
              <div className="relative ml-auto">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="appearance-none pl-4 pr-10 py-2.5 rounded-lg border border-champagne/30 bg-porcelain text-sm text-mocha outline-none focus:border-antique-gold transition-colors cursor-pointer"
                >
                  <option value="created_at">Newest</option>
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                  <option value="rating">Top Rated</option>
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-taupe pointer-events-none" />
              </div>
            </div>

            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {Array.from({ length: 9 }).map((_, i) => (
                  <div key={i} className="card-luxury overflow-hidden">
                    <div className="aspect-[4/5] skeleton" />
                    <div className="p-4 space-y-2">
                      <div className="h-3 w-20 skeleton rounded" />
                      <div className="h-4 w-full skeleton rounded" />
                      <div className="h-4 w-1/2 skeleton rounded" />
                    </div>
                  </div>
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-24">
                <p className="text-mocha font-medium text-lg">No products found</p>
                <p className="text-sm text-taupe mt-2">Try adjusting your filters or search terms.</p>
                <button onClick={clearFilters} className="btn-outline mt-4">Clear Filters</button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {products.map((p) => (
                  <ProductCard key={p.id} product={p} merchantName={p.merchants?.name} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile filter drawer */}
      {showFilters && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-deep-brown/40 backdrop-blur-sm" onClick={() => setShowFilters(false)} />
          <div className="absolute bottom-0 left-0 right-0 max-h-[80vh] bg-ivory rounded-t-2xl p-6 overflow-y-auto animate-slide-up">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-serif text-lg font-medium text-mocha">Filters</h2>
              <button onClick={() => setShowFilters(false)} className="p-2 text-mocha"><X size={20} /></button>
            </div>
            <FilterContent />
            <button onClick={() => setShowFilters(false)} className="btn-primary w-full mt-6">
              Show {products.length} Results
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
