import { useShop } from '@/context/ShopContext';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { Heart, ShoppingBag } from 'lucide-react';
import { ProductCard } from '@/components/ProductCard';

export function WishlistPage() {
  const { wishlistItems } = useShop();
  const { session } = useAuth();
  const { navigate } = useRouter();

  if (!session) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <Heart size={48} className="text-champagne mx-auto mb-4" />
        <p className="text-mocha font-medium text-lg">Please sign in to view your wishlist</p>
        <button onClick={() => navigate('/signin')} className="btn-primary mt-4">Sign In</button>
      </div>
    );
  }

  return (
    <div className="pb-20 lg:pb-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="section-heading">My Wishlist</h1>
      <div className="section-divider mt-2 w-24" />
      <p className="text-sm text-taupe mt-3 mb-8">{wishlistItems.length} saved {wishlistItems.length === 1 ? 'item' : 'items'}</p>

      {wishlistItems.length === 0 ? (
        <div className="text-center py-24">
          <Heart size={48} className="text-champagne mx-auto mb-4" />
          <p className="text-mocha font-medium text-lg">Your wishlist is empty</p>
          <p className="text-sm text-taupe mt-2 mb-4">Save your favorite pieces for later.</p>
          <button onClick={() => navigate('/')} className="btn-primary">
            <ShoppingBag size={16} /> Start Shopping
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {wishlistItems.map((item) => (
            <ProductCard key={item.id} product={item.products!} />
          ))}
        </div>
      )}
    </div>
  );
}
