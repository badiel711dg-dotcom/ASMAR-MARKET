import { useState } from 'react';
import { ShoppingBag, Plus, Minus, X, ArrowRight, CreditCard, Truck } from 'lucide-react';
import { useShop } from '@/context/ShopContext';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { supabase } from '@/lib/supabase';
import { formatPrice } from '@/lib/utils';

export function CartPage() {
  const { cartItems, updateCartQty, removeFromCart, refreshCart } = useShop();
  const { session } = useAuth();
  const { navigate } = useRouter();

  const subtotal = cartItems.reduce((sum, item) => sum + (item.products?.price ?? 0) * item.quantity, 0);
  const shipping = subtotal >= 200 ? 0 : 15;
  const total = subtotal + shipping;

  if (!session) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <ShoppingBag size={48} className="text-champagne mx-auto mb-4" />
        <p className="text-mocha font-medium text-lg">Please sign in to view your bag</p>
        <button onClick={() => navigate('/signin')} className="btn-primary mt-4">Sign In</button>
      </div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <ShoppingBag size={48} className="text-champagne mx-auto mb-4" />
        <p className="text-mocha font-medium text-lg">Your bag is empty</p>
        <p className="text-sm text-taupe mt-2 mb-4">Discover our curated collection of luxury pieces.</p>
        <button onClick={() => navigate('/')} className="btn-primary">Start Shopping</button>
      </div>
    );
  }

  return (
    <div className="pb-20 lg:pb-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="section-heading">Shopping Bag</h1>
      <div className="section-divider mt-2 w-24" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
        {/* Items */}
        <div className="lg:col-span-2 space-y-4">
          {cartItems.map((item) => (
            <div key={item.id} className="card-luxury p-4 flex gap-4">
              <div className="w-24 h-28 rounded-lg overflow-hidden bg-ivory flex-shrink-0 border border-champagne/20">
                {item.products?.images?.[0] && (
                  <img src={item.products.images[0]} alt={item.products.name} className="w-full h-full object-cover" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-serif text-base font-medium text-mocha">{item.products?.name}</h3>
                  <button onClick={() => removeFromCart(item.id)} className="text-taupe hover:text-dusty-rose-dark transition-colors">
                    <X size={18} />
                  </button>
                </div>
                {item.variant && (
                  <p className="text-xs text-taupe mt-1">
                    {Object.entries(item.variant).map(([k, v]) => `${k}: ${v}`).join(' · ')}
                  </p>
                )}
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center border border-champagne/30 rounded-lg overflow-hidden">
                    <button onClick={() => updateCartQty(item.id, item.quantity - 1)} className="px-3 py-2 text-mocha hover:bg-champagne/15 transition-colors">
                      <Minus size={14} />
                    </button>
                    <span className="px-4 text-sm font-medium text-mocha">{item.quantity}</span>
                    <button onClick={() => updateCartQty(item.id, item.quantity + 1)} className="px-3 py-2 text-mocha hover:bg-champagne/15 transition-colors">
                      <Plus size={14} />
                    </button>
                  </div>
                  <span className="font-serif text-lg font-semibold text-mocha">
                    {formatPrice((item.products?.price ?? 0) * item.quantity)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="card-luxury p-6 h-fit sticky top-24 space-y-4">
          <h2 className="font-serif text-lg font-medium text-mocha">Order Summary</h2>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-taupe">Subtotal</span><span className="text-mocha font-medium">{formatPrice(subtotal)}</span></div>
            <div className="flex justify-between"><span className="text-taupe">Shipping</span><span className="text-mocha font-medium">{shipping === 0 ? 'Free' : formatPrice(shipping)}</span></div>
            {shipping > 0 && (
              <p className="text-xs text-antique-gold">Add {formatPrice(200 - subtotal)} more for free shipping</p>
            )}
          </div>
          <div className="pt-4 border-t border-champagne/20 flex justify-between items-baseline">
            <span className="font-medium text-mocha">Total</span>
            <span className="font-serif text-2xl font-semibold text-mocha">{formatPrice(total)}</span>
          </div>
          <button onClick={() => navigate('/checkout')} className="btn-primary w-full">
            Proceed to Checkout <ArrowRight size={16} />
          </button>
          <button onClick={() => navigate('/')} className="btn-outline w-full">Continue Shopping</button>
        </div>
      </div>
    </div>
  );
}

export function CheckoutPage() {
  const { cartItems, refreshCart } = useShop();
  const { session } = useAuth();
  const { navigate } = useRouter();
  const [form, setForm] = useState({
    full_name: '', email: '', phone: '', address: '', city: '', state: '', zip: '', country: '',
    card_number: '', card_name: '', card_exp: '', card_cvc: '', notes: '',
  });
  const [placing, setPlacing] = useState(false);
  const [orderComplete, setOrderComplete] = useState<string | null>(null);

  const subtotal = cartItems.reduce((sum, item) => sum + (item.products?.price ?? 0) * item.quantity, 0);
  const shipping = subtotal >= 200 ? 0 : 15;
  const total = subtotal + shipping;

  if (!session) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <p className="text-mocha font-medium text-lg">Please sign in to checkout</p>
        <button onClick={() => navigate('/signin')} className="btn-primary mt-4">Sign In</button>
      </div>
    );
  }

  if (orderComplete) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-24 text-center">
        <div className="w-20 h-20 rounded-full bg-champagne/20 flex items-center justify-center mx-auto mb-6">
          <ShoppingBag size={36} className="text-antique-gold" />
        </div>
        <h1 className="font-serif text-3xl font-semibold text-mocha">Order Confirmed</h1>
        <p className="text-sm text-taupe mt-3 mb-2">Thank you for your purchase. Your order has been placed successfully.</p>
        <p className="text-xs text-taupe">Order reference: {orderComplete}</p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center mt-8">
          <button onClick={() => navigate('/account')} className="btn-primary">View My Orders</button>
          <button onClick={() => navigate('/')} className="btn-outline">Continue Shopping</button>
        </div>
      </div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <p className="text-mocha font-medium text-lg">Your bag is empty</p>
        <button onClick={() => navigate('/')} className="btn-primary mt-4">Start Shopping</button>
      </div>
    );
  }

  const handlePlaceOrder = async () => {
    setPlacing(true);
    const shippingAddress = {
      full_name: form.full_name, email: form.email, phone: form.phone,
      address: form.address, city: form.city, state: form.state, zip: form.zip, country: form.country,
    };
    const { data: order } = await supabase.from('orders').insert({
      user_id: session.user.id, total, status: 'pending',
      shipping_address: shippingAddress, notes: form.notes || null,
    }).select().maybeSingle();

    if (order) {
      const orderItems = cartItems.map((item) => ({
        order_id: order.id,
        product_id: item.product_id,
        product_name: item.products?.name ?? '',
        quantity: item.quantity,
        price: item.products?.price ?? 0,
        variant: item.variant,
        image_url: item.products?.images?.[0] ?? null,
      }));
      await supabase.from('order_items').insert(orderItems);
      await supabase.from('cart_items').delete().eq('user_id', session.user.id);
      await refreshCart();
      setOrderComplete(order.id);
    }
    setPlacing(false);
  };

  return (
    <div className="pb-20 lg:pb-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="section-heading">Checkout</h1>
      <div className="section-divider mt-2 w-24" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
        <div className="lg:col-span-2 space-y-8">
          {/* Shipping */}
          <div className="card-luxury p-6 space-y-4">
            <h2 className="font-serif text-lg font-medium text-mocha flex items-center gap-2">
              <Truck size={18} className="text-antique-gold" /> Shipping Information
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <input className="input-luxury" placeholder="Full Name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
              <input className="input-luxury" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              <input className="input-luxury" placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              <input className="input-luxury" placeholder="Country" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} />
              <input className="input-luxury sm:col-span-2" placeholder="Street Address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
              <input className="input-luxury" placeholder="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
              <div className="grid grid-cols-2 gap-4">
                <input className="input-luxury" placeholder="State" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} />
                <input className="input-luxury" placeholder="ZIP" value={form.zip} onChange={(e) => setForm({ ...form, zip: e.target.value })} />
              </div>
            </div>
          </div>

          {/* Payment */}
          <div className="card-luxury p-6 space-y-4">
            <h2 className="font-serif text-lg font-medium text-mocha flex items-center gap-2">
              <CreditCard size={18} className="text-antique-gold" /> Payment Details
            </h2>
            <p className="text-xs text-taupe">This is a demo checkout — no real payment will be processed.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <input className="input-luxury sm:col-span-2" placeholder="Card Number" value={form.card_number} onChange={(e) => setForm({ ...form, card_number: e.target.value })} />
              <input className="input-luxury sm:col-span-2" placeholder="Name on Card" value={form.card_name} onChange={(e) => setForm({ ...form, card_name: e.target.value })} />
              <input className="input-luxury" placeholder="MM/YY" value={form.card_exp} onChange={(e) => setForm({ ...form, card_exp: e.target.value })} />
              <input className="input-luxury" placeholder="CVC" value={form.card_cvc} onChange={(e) => setForm({ ...form, card_cvc: e.target.value })} />
            </div>
          </div>

          {/* Notes */}
          <div className="card-luxury p-6">
            <label className="block text-xs font-medium text-taupe uppercase tracking-wider mb-2">Order Notes (Optional)</label>
            <textarea className="input-luxury resize-none" rows={3} placeholder="Special delivery instructions..." value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          </div>
        </div>

        {/* Summary */}
        <div className="card-luxury p-6 h-fit sticky top-24 space-y-4">
          <h2 className="font-serif text-lg font-medium text-mocha">Your Order</h2>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {cartItems.map((item) => (
              <div key={item.id} className="flex gap-3 text-sm">
                <div className="w-14 h-16 rounded overflow-hidden bg-ivory flex-shrink-0 border border-champagne/20">
                  {item.products?.images?.[0] && <img src={item.products.images[0]} alt="" className="w-full h-full object-cover" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-mocha font-medium line-clamp-1">{item.products?.name}</p>
                  <p className="text-xs text-taupe">Qty: {item.quantity}</p>
                </div>
                <span className="text-mocha font-medium">{formatPrice((item.products?.price ?? 0) * item.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="pt-4 border-t border-champagne/20 space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-taupe">Subtotal</span><span className="text-mocha">{formatPrice(subtotal)}</span></div>
            <div className="flex justify-between"><span className="text-taupe">Shipping</span><span className="text-mocha">{shipping === 0 ? 'Free' : formatPrice(shipping)}</span></div>
          </div>
          <div className="pt-3 border-t border-champagne/20 flex justify-between items-baseline">
            <span className="font-medium text-mocha">Total</span>
            <span className="font-serif text-2xl font-semibold text-mocha">{formatPrice(total)}</span>
          </div>
          <button onClick={handlePlaceOrder} disabled={placing} className="btn-primary w-full">
            {placing ? 'Placing Order...' : 'Place Order'}
          </button>
        </div>
      </div>
    </div>
  );
}
