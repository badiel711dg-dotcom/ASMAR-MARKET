export type Product = {
  id: string;
  merchant_id: string;
  category_id: string | null;
  name: string;
  slug: string;
  description: string | null;
  price: number;
  compare_at_price: number | null;
  stock: number;
  sku: string | null;
  images: string[];
  variants: Variant[];
  is_active: boolean;
  is_featured: boolean;
  is_new: boolean;
  rating_avg: number;
  review_count: number;
  like_count: number;
  created_at: string;
};

export type Variant = {
  name: string;
  options: string[];
};

export type Category = {
  id: string;
  name: string;
  name_ar: string | null;
  slug: string;
  description: string | null;
  image_url: string | null;
  parent_id: string | null;
  sort_order: number;
};

export type Merchant = {
  id: string;
  owner_id: string | null;
  name: string;
  slug: string;
  description: string | null;
  logo_url: string | null;
  cover_url: string | null;
  theme: { primary: string; accent: string };
  is_approved: boolean;
  is_active: boolean;
  created_at: string;
};

export type Review = {
  id: string;
  product_id: string;
  user_id: string;
  rating: number;
  comment: string | null;
  is_verified_purchase: boolean;
  created_at: string;
  profiles?: { display_name: string } | null;
};

export type CartItem = {
  id: string;
  user_id: string;
  product_id: string;
  quantity: number;
  variant: Record<string, string> | null;
  products?: Product;
};

export type WishlistItem = {
  id: string;
  user_id: string;
  product_id: string;
  created_at: string;
  products?: Product;
};

export type Order = {
  id: string;
  user_id: string;
  status: string;
  total: number;
  shipping_address: Record<string, string> | null;
  notes: string | null;
  created_at: string;
};

export type OrderItem = {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  quantity: number;
  price: number;
  variant: Record<string, string> | null;
  image_url: string | null;
};

export type Profile = {
  id: string;
  email: string;
  display_name: string;
  role: 'customer' | 'merchant' | 'owner';
  avatar_url: string | null;
  phone: string | null;
  bio: string | null;
};

export type ProductWithMerchant = Product & {
  merchants?: Merchant;
  categories?: Category | null;
};

export type MerchantWithCounts = Merchant & {
  product_count?: number;
  follower_count?: number;
};
