import { Heart } from 'lucide-react';
import { useShop } from '@/context/ShopContext';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';

type Props = {
  productId: string;
  likeCount?: number;
  className?: string;
  size?: number;
};

export function WishlistButton({ productId, likeCount, className = '', size = 20 }: Props) {
  const { toggleWishlist, isInWishlist } = useShop();
  const { session } = useAuth();
  const { navigate } = useRouter();
  const active = isInWishlist(productId);

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!session) {
      navigate('/signin');
      return;
    }
    toggleWishlist(productId);
  };

  return (
    <button
      onClick={handleClick}
      aria-label={active ? 'Remove from wishlist' : 'Add to wishlist'}
      className={`group/heart relative flex items-center justify-center w-9 h-9 rounded-full
        bg-porcelain/80 backdrop-blur-sm border border-champagne/20
        transition-all duration-300 hover:border-antique-gold/50
        ${className}`}
    >
      <Heart
        size={size}
        className={`transition-all duration-300 ${
          active
            ? 'fill-dusty-rose-dark text-dusty-rose-dark scale-110'
            : 'fill-transparent text-mocha group-hover/heart:text-antique-gold'
        }`}
      />
      {likeCount !== undefined && likeCount > 0 && (
        <span className="absolute -bottom-1 -right-1 text-[10px] font-medium text-taupe bg-ivory rounded-full px-1">
          {likeCount}
        </span>
      )}
    </button>
  );
}
