import { useState } from 'react';
import { ChevronRight } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';
import { supabase } from '@/lib/supabase';

const WELCOME_KEY = 'moder_one_welcome_seen';

export function WelcomeScreen({ onEnter }: { onEnter: () => void }) {
  const [entering, setEntering] = useState(false);
  const { navigate } = useRouter();

  const handleEnter = async () => {
    setEntering(true);
    localStorage.setItem(WELCOME_KEY, Date.now().toString());
    // Check if we have an active session
    const { data: { session } } = await supabase.auth.getSession();
    setTimeout(() => {
      if (session) {
        navigate('/account');
      } else {
        onEnter();
      }
    }, 800);
  };

  const handleSkip = () => {
    localStorage.setItem(WELCOME_KEY, Date.now().toString());
    onEnter();
  };

  return (
    <div className={`fixed inset-0 z-[100] bg-ivory flex flex-col items-center justify-center px-6
      transition-opacity duration-700 ${entering ? 'opacity-0' : 'opacity-100'}`}>
      {/* Ambient gradient background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 rounded-full bg-champagne/10 blur-3xl animate-fade-in" style={{ animationDuration: '3s' }} />
        <div className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 rounded-full bg-dusty-rose/20 blur-3xl animate-fade-in" style={{ animationDuration: '3s', animationDelay: '0.5s' }} />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-2xl">
        {/* Logo */}
        <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-semibold text-mocha tracking-wide opacity-0 animate-fade-in-up"
            style={{ animationDelay: '0.3s' }}>
          MODER <span className="text-antique-gold">ONE</span>
        </h1>

        {/* Divider */}
        <div className="w-16 h-px bg-gradient-to-r from-transparent via-champagne to-transparent my-6 opacity-0 animate-fade-in"
             style={{ animationDelay: '0.8s' }} />

        {/* Tagline */}
        <p className="font-sans text-sm sm:text-base tracking-[0.3em] uppercase text-taupe opacity-0 animate-fade-in-up"
           style={{ animationDelay: '1s' }}>
          Shop. Discover. Belong.
        </p>

        {/* Arabic welcome */}
        <p className="font-arabic text-lg sm:text-xl text-mocha/70 mt-6 opacity-0 animate-fade-in-up" dir="rtl"
           style={{ animationDelay: '1.5s' }}>
          اكتشف عالمًا صُمّم حول ذوقك
        </p>

        {/* Enter button */}
        <button
          onClick={handleEnter}
          className="mt-12 px-10 py-4 rounded-lg bg-champagne/90 text-deep-brown font-medium text-sm tracking-wider uppercase
            border border-antique-gold/40 backdrop-blur-sm
            hover:bg-champagne hover:shadow-luxury-md hover:scale-105
            active:scale-95 transition-all duration-500
            opacity-0 animate-fade-in-up"
          style={{ animationDelay: '2s' }}
        >
          Discover Moder One
        </button>

        {/* Skip */}
        <button
          onClick={handleSkip}
          className="mt-6 text-xs text-taupe hover:text-mocha transition-colors opacity-0 animate-fade-in"
          style={{ animationDelay: '2.5s' }}
        >
          Skip introduction
        </button>
      </div>

      {/* Bottom brand line */}
      <div className="absolute bottom-6 left-0 right-0 flex items-center justify-center gap-2 opacity-0 animate-fade-in"
           style={{ animationDelay: '3s' }}>
        <ChevronRight size={14} className="text-antique-gold/60" />
        <span className="text-[10px] tracking-[0.2em] uppercase text-taupe/60">An Exclusive Marketplace</span>
        <ChevronRight size={14} className="text-antique-gold/60" />
      </div>
    </div>
  );
}

export function hasSeenWelcome(): boolean {
  return localStorage.getItem(WELCOME_KEY) !== null;
}
