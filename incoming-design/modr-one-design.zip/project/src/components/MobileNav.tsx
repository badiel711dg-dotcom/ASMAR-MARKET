import { Home, Grid, Heart, ShoppingBag, User } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';
import { useShop } from '@/context/ShopContext';

export function MobileNav() {
  const { navigate } = useRouter();
  const { cartCount, setCartOpen, wishlistCount } = useShop();

  const items = [
    { label: 'Home', icon: Home, path: '/', action: () => navigate('/') },
    { label: 'Browse', icon: Grid, path: '/categories', action: () => navigate('/categories') },
    { label: 'Wishlist', icon: Heart, path: '/wishlist', action: () => navigate('/wishlist'), badge: wishlistCount },
    { label: 'Bag', icon: ShoppingBag, action: () => setCartOpen(true), badge: cartCount },
    { label: 'Account', icon: User, path: '/account', action: () => navigate('/account') },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-ivory/95 backdrop-blur-md border-t border-champagne/20">
      <div className="flex items-center justify-around h-14">
        {items.map((item) => (
          <button
            key={item.label}
            onClick={item.action}
            className="relative flex flex-col items-center justify-center gap-0.5 px-2 py-1 text-taupe hover:text-antique-gold transition-colors"
          >
            <item.icon size={20} />
            <span className="text-[10px] font-medium">{item.label}</span>
            {item.badge !== undefined && item.badge > 0 && (
              <span className="absolute top-0 right-1 w-4 h-4 text-[9px] font-medium bg-mocha text-porcelain rounded-full flex items-center justify-center">
                {item.badge}
              </span>
            )}
          </button>
        ))}
      </div>
    </nav>
  );
}
