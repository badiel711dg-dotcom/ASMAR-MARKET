import { Store } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';
import type { MerchantWithCounts } from '@/types';

type Props = {
  merchant: MerchantWithCounts;
};

export function MerchantCard({ merchant }: Props) {
  const { navigate } = useRouter();

  return (
    <div
      onClick={() => navigate(`/stores/${merchant.slug}`)}
      className="group cursor-pointer card-luxury overflow-hidden hover:shadow-luxury-md hover:-translate-y-0.5"
    >
      <div className="relative h-32 overflow-hidden bg-ivory">
        {merchant.cover_url ? (
          <img
            src={merchant.cover_url}
            alt={merchant.name}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-dusty-rose/30">
            <Store size={28} className="text-antique-gold" />
          </div>
        )}
      </div>
      <div className="p-4 flex items-center gap-3">
        <div className="w-12 h-12 rounded-full overflow-hidden border border-champagne/30 flex-shrink-0">
          {merchant.logo_url ? (
            <img src={merchant.logo_url} alt={merchant.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-champagne/20">
              <Store size={18} className="text-antique-gold" />
            </div>
          )}
        </div>
        <div className="min-w-0">
          <h3 className="font-serif text-base font-medium text-mocha truncate">{merchant.name}</h3>
          <p className="text-xs text-taupe line-clamp-1">{merchant.description}</p>
          {merchant.product_count !== undefined && (
            <p className="text-[11px] text-antique-gold mt-0.5">{merchant.product_count} products</p>
          )}
        </div>
      </div>
    </div>
  );
}
