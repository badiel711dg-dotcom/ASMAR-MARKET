import { useState, useEffect, useRef } from 'react';
import { Search, Heart, ShoppingBag, User, Menu, X, Home, Grid, Store } from 'lucide-react';
import { useShop } from '@/context/ShopContext';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { supabase } from '@/lib/supabase';
import type { Category, Product } from '@/types';
import { ProductCard } from './ProductCard';

export function Header() {
  const { cartCount, setCartOpen, wishlistCount } = useShop();
  const { session, profile } = useAuth();
  const { navigate } = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState<Category[]>([]);
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.from('categories').select('*').order('sort_order').then(({ data }) => {
      setCategories((data as Category[]) ?? []);
    });
  }, []);

  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const timer = setTimeout(async () => {
      const { data } = await supabase
        .from('products')
        .select('*, merchants(name)')
        .ilike('name', `%${searchQuery}%`)
        .limit(6);
      setSearchResults((data as Product[]) ?? []);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const navItems = [
    { label: 'Home', path: '/', icon: Home },
    { label: 'Categories', path: '/categories', icon: Grid },
    { label: 'Stores', path: '/stores', icon: Store },
  ];

  return (
    <>
      <header className="sticky top-0 z-50 bg-ivory/95 backdrop-blur-md border-b border-champagne/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Mobile menu button */}
            <button
              onClick={() => setMobileOpen(true)}
              className="lg:hidden p-2 -ml-2 text-mocha hover:text-antique-gold transition-colors"
              aria-label="Open menu"
            >
              <Menu size={22} />
            </button>

            {/* Logo */}
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-1 group"
            >
              <span className="font-serif text-xl lg:text-2xl font-semibold tracking-wide text-mocha
                group-hover:text-antique-gold transition-colors">
                MODER <span className="text-antique-gold">ONE</span>
              </span>
            </button>

            {/* Desktop nav */}
            <nav className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className="px-4 py-2 rounded-lg text-sm font-medium text-mocha
                    hover:bg-dusty-rose/30 hover:text-antique-gold
                    transition-all duration-200"
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Right actions */}
            <div className="flex items-center gap-1 sm:gap-2">
              {/* Search */}
              <div ref={searchRef} className="relative">
                <button
                  onClick={() => setSearchOpen(!searchOpen)}
                  className="p-2 rounded-lg text-mocha hover:bg-dusty-rose/30 hover:text-antique-gold transition-all"
                  aria-label="Search"
                >
                  <Search size={20} />
                </button>
                {searchOpen && (
                  <div className="absolute right-0 top-full mt-2 w-80 sm:w-96 bg-porcelain rounded-xl border border-champagne/30 shadow-luxury-lg p-4 animate-slide-in-right z-50">
                    <div className="relative">
                      <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-taupe" />
                      <input
                        autoFocus
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search products, brands..."
                        className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-ivory border border-champagne/30 text-sm text-mocha outline-none focus:border-antique-gold transition-colors"
                      />
                    </div>
                    {searchResults.length > 0 && (
                      <div className="mt-3 grid grid-cols-2 gap-2 max-h-96 overflow-y-auto">
                        {searchResults.map((p) => (
                          <ProductCard key={p.id} product={p} merchantName={(p as { merchants?: { name: string } }).merchants?.name} />
                        ))}
                      </div>
                    )}
                    {searchQuery && searchResults.length === 0 && (
                      <p className="mt-3 text-sm text-taupe text-center py-4">No results found</p>
                    )}
                    {!searchQuery && (
                      <div className="mt-3 flex flex-wrap gap-2">
                        {categories.slice(0, 5).map((c) => (
                          <button
                            key={c.id}
                            onClick={() => { navigate(`/categories/${c.slug}`); setSearchOpen(false); }}
                            className="px-3 py-1.5 text-xs rounded-full bg-dusty-rose/30 text-mocha hover:bg-champagne/30 transition-colors"
                          >
                            {c.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Account */}
              <button
                onClick={() => navigate(session ? '/account' : '/signin')}
                className="p-2 rounded-lg text-mocha hover:bg-dusty-rose/30 hover:text-antique-gold transition-all"
                aria-label="Account"
              >
                <User size={20} />
              </button>

              {/* Wishlist */}
              <button
                onClick={() => navigate('/wishlist')}
                className="p-2 rounded-lg text-mocha hover:bg-dusty-rose/30 hover:text-antique-gold transition-all relative"
                aria-label="Wishlist"
              >
                <Heart size={20} />
                {wishlistCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 text-[10px] font-medium
                    bg-dusty-rose-dark text-white rounded-full flex items-center justify-center">
                    {wishlistCount}
                  </span>
                )}
              </button>

              {/* Cart */}
              <button
                onClick={() => setCartOpen(true)}
                className="p-2 rounded-lg text-mocha hover:bg-dusty-rose/30 hover:text-antique-gold transition-all relative"
                aria-label="Shopping bag"
              >
                <ShoppingBag size={20} />
                {cartCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 text-[10px] font-medium
                    bg-mocha text-porcelain rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-deep-brown/40 backdrop-blur-sm animate-fade-in" onClick={() => setMobileOpen(false)} />
          <div className="absolute left-0 top-0 bottom-0 w-72 bg-ivory shadow-luxury-lg animate-slide-in-right">
            <div className="flex items-center justify-between p-4 border-b border-champagne/20">
              <span className="font-serif text-lg font-semibold text-mocha">MODER <span className="text-antique-gold">ONE</span></span>
              <button onClick={() => setMobileOpen(false)} className="p-2 text-mocha"><X size={20} /></button>
            </div>
            <nav className="p-4 space-y-1">
              {navItems.map((item) => (
                <button
                  key={item.path}
                  onClick={() => { navigate(item.path); setMobileOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-mocha hover:bg-dusty-rose/30 transition-colors text-sm font-medium"
                >
                  <item.icon size={18} className="text-antique-gold" />
                  {item.label}
                </button>
              ))}
              <div className="pt-4 mt-4 border-t border-champagne/20">
                <p className="px-4 text-xs text-taupe uppercase tracking-wider mb-2">Categories</p>
                {categories.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => { navigate(`/categories/${c.slug}`); setMobileOpen(false); }}
                    className="w-full text-left px-4 py-2 rounded-lg text-sm text-mocha hover:bg-dusty-rose/30 transition-colors"
                  >
                    {c.name}
                  </button>
                ))}
              </div>
              <div className="pt-4 mt-4 border-t border-champagne/20">
                <button
                  onClick={() => { navigate(session ? '/account' : '/signin'); setMobileOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-mocha hover:bg-dusty-rose/30 transition-colors text-sm font-medium"
                >
                  <User size={18} className="text-antique-gold" />
                  {session ? (profile?.display_name || 'My Account') : 'Sign In'}
                </button>
              </div>
            </nav>
          </div>
        </div>
      )}
    </>
  );
}
