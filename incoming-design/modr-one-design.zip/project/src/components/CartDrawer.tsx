import { ShoppingBag, X, Plus, Minus, ArrowRight } from 'lucide-react';
import { useShop } from '@/context/ShopContext';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { formatPrice } from '@/lib/utils';

export function CartDrawer() {
  const { cartItems, cartOpen, setCartOpen, updateCartQty, removeFromCart, cartCount } = useShop();
  const { session } = useAuth();
  const { navigate } = useRouter();

  if (!cartOpen) return null;

  const subtotal = cartItems.reduce((sum, item) => {
    return sum + (item.products?.price ?? 0) * item.quantity;
  }, 0);

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-deep-brown/40 backdrop-blur-sm animate-fade-in" onClick={() => setCartOpen(false)} />
      <div className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-ivory shadow-luxury-lg flex flex-col animate-slide-in-right">
        <div className="flex items-center justify-between p-5 border-b border-champagne/20">
          <div className="flex items-center gap-2">
            <ShoppingBag size={20} className="text-antique-gold" />
            <h2 className="font-serif text-lg font-medium text-mocha">
              Shopping Bag {cartCount > 0 && `(${cartCount})`}
            </h2>
          </div>
          <button onClick={() => setCartOpen(false)} className="p-2 text-mocha hover:text-antique-gold transition-colors">
            <X size={20} />
          </button>
        </div>

        {!session ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <ShoppingBag size={48} className="text-champagne mb-4" />
            <p className="text-mocha font-medium mb-2">Please sign in to view your bag</p>
            <button onClick={() => { setCartOpen(false); navigate('/signin'); }} className="btn-primary mt-4">
              Sign In
            </button>
          </div>
        ) : cartItems.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <ShoppingBag size={48} className="text-champagne mb-4" />
            <p className="text-mocha font-medium mb-2">Your bag is empty</p>
            <p className="text-sm text-taupe mb-4">Discover our curated collection of luxury pieces.</p>
            <button onClick={() => { setCartOpen(false); navigate('/'); }} className="btn-primary">
              Start Shopping
            </button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {cartItems.map((item) => (
                <div key={item.id} className="flex gap-3 pb-4 border-b border-champagne/10 last:border-0">
                  <div className="w-20 h-24 rounded-lg overflow-hidden bg-ivory flex-shrink-0 border border-champagne/20">
                    {item.products?.images?.[0] && (
                      <img src={item.products.images[0]} alt={item.products.name} className="w-full h-full object-cover" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-serif text-sm font-medium text-mocha line-clamp-2">{item.products?.name}</h3>
                    {item.variant && (
                      <p className="text-xs text-taupe mt-0.5">
                        {Object.entries(item.variant).map(([k, v]) => `${k}: ${v}`).join(', ')}
                      </p>
                    )}
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateCartQty(item.id, item.quantity - 1)}
                          className="w-7 h-7 rounded-full border border-champagne/30 flex items-center justify-center text-mocha hover:bg-champagne/20 transition-colors"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="text-sm font-medium text-mocha w-6 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateCartQty(item.id, item.quantity + 1)}
                          className="w-7 h-7 rounded-full border border-champagne/30 flex items-center justify-center text-mocha hover:bg-champagne/20 transition-colors"
                        >
                          <Plus size={12} />
                        </button>
                      </div>
                      <span className="text-sm font-semibold text-mocha">
                        {formatPrice((item.products?.price ?? 0) * item.quantity)}
                      </span>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-xs text-taupe hover:text-dusty-rose-dark transition-colors mt-2"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-5 border-t border-champagne/20 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-taupe">Subtotal</span>
                <span className="font-serif text-lg font-semibold text-mocha">{formatPrice(subtotal)}</span>
              </div>
              <p className="text-xs text-taupe">Shipping and taxes calculated at checkout.</p>
              <button
                onClick={() => { setCartOpen(false); navigate('/cart'); }}
                className="btn-outline w-full"
              >
                View Bag
              </button>
              <button
                onClick={() => { setCartOpen(false); navigate('/checkout'); }}
                className="btn-primary w-full"
              >
                Proceed to Checkout <ArrowRight size={16} />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
