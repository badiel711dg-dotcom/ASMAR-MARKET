import { ShoppingBag } from 'lucide-react';
import { useShop } from '@/context/ShopContext';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import type { Product } from '@/types';
import { formatPrice } from '@/lib/utils';
import { useState } from 'react';
import { StarRating } from './StarRating';
import { WishlistButton } from './WishlistButton';

type Props = {
  product: Product;
  merchantName?: string;
};

export function ProductCard({ product, merchantName }: Props) {
  const { addToCart } = useShop();
  const { session } = useAuth();
  const { navigate } = useRouter();
  const [adding, setAdding] = useState(false);

  const images = product.images ?? [];
  const primaryImage = images[0] ?? '';
  const hasDiscount = product.compare_at_price && product.compare_at_price > product.price;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!session) {
      navigate('/signin');
      return;
    }
    if (product.stock <= 0) return;
    setAdding(true);
    const defaultVariant: Record<string, string> | null = null;
    addToCart(product.id, 1, defaultVariant).finally(() => {
      setTimeout(() => setAdding(false), 600);
    });
  };

  const goToProduct = () => navigate(`/products/${product.id}`);

  return (
    <div
      onClick={goToProduct}
      className="group cursor-pointer card-luxury overflow-hidden hover:shadow-luxury-md hover:-translate-y-0.5"
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-ivory">
        {primaryImage ? (
          <img
            src={primaryImage}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-taupe/40">
            <ShoppingBag size={32} />
          </div>
        )}
        {product.is_new && (
          <span className="absolute top-3 left-3 px-2.5 py-1 text-[10px] font-medium tracking-wider uppercase
            bg-porcelain/90 text-antique-gold rounded-full border border-champagne/30 backdrop-blur-sm">
            New
          </span>
        )}
        {hasDiscount && (
          <span className="absolute top-3 right-3 px-2.5 py-1 text-[10px] font-medium tracking-wider
            bg-mocha text-porcelain rounded-full">
            −{Math.round((1 - product.price / (product.compare_at_price as number)) * 100)}%
          </span>
        )}
        <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <WishlistButton productId={product.id} likeCount={product.like_count} />
        </div>
        {product.stock <= 0 && (
          <div className="absolute inset-0 bg-ivory/60 flex items-center justify-center">
            <span className="text-sm font-medium text-mocha tracking-wider uppercase">Sold Out</span>
          </div>
        )}
      </div>

      <div className="p-4 space-y-2">
        {merchantName && (
          <p className="text-[11px] text-taupe tracking-wider uppercase truncate">{merchantName}</p>
        )}
        <h3 className="font-serif text-base font-medium text-mocha leading-snug line-clamp-2">
          {product.name}
        </h3>
        <StarRating rating={product.rating_avg} count={product.review_count} />
        <div className="flex items-center justify-between pt-1">
          <div className="flex items-baseline gap-2">
            <span className="font-sans text-base font-semibold text-mocha">
              {formatPrice(product.price)}
            </span>
            {hasDiscount && (
              <span className="text-xs text-taupe line-through">
                {formatPrice(product.compare_at_price as number)}
              </span>
            )}
          </div>
          <button
            onClick={handleAddToCart}
            disabled={product.stock <= 0 || adding}
            aria-label="Add to bag"
            className="flex items-center justify-center w-9 h-9 rounded-lg
              bg-champagne/15 text-mocha border border-champagne/30
              transition-all duration-300 hover:bg-champagne hover:text-deep-brown
              active:scale-90 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ShoppingBag size={16} className={adding ? 'animate-pulse' : ''} />
          </button>
        </div>
      </div>
    </div>
  );
}
