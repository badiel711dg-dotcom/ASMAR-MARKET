import { Mail, Phone, MapPin, Instagram, Facebook, Twitter } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';

export function Footer() {
  const { navigate } = useRouter();

  const columns = [
    {
      title: 'Shop',
      links: [
        { label: 'All Products', path: '/categories' },
        { label: 'Featured', path: '/' },
        { label: 'New Arrivals', path: '/' },
        { label: 'Stores', path: '/stores' },
      ],
    },
    {
      title: 'Customer Care',
      links: [
        { label: 'My Account', path: '/account' },
        { label: 'My Orders', path: '/account' },
        { label: 'Wishlist', path: '/wishlist' },
        { label: 'Shopping Bag', path: '/cart' },
      ],
    },
    {
      title: 'About',
      links: [
        { label: 'Our Story', path: '/' },
        { label: 'Become a Merchant', path: '/signup' },
        { label: 'Privacy Policy', path: '/' },
        { label: 'Terms of Service', path: '/' },
      ],
    },
  ];

  return (
    <footer className="bg-deep-brown text-porcelain mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="font-serif text-2xl font-semibold">
              MODER <span className="text-champagne">ONE</span>
            </h3>
            <p className="text-sm text-porcelain/60 leading-relaxed max-w-xs">
              A refined destination for discovering exceptional products from independent merchants worldwide.
            </p>
            <p className="font-arabic text-sm text-champagne/70" dir="rtl">
              تسوّق. اكتشف. انتمِ.
            </p>
            <div className="flex items-center gap-3 pt-2">
              {[Instagram, Facebook, Twitter].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className="w-9 h-9 rounded-full border border-champagne/30 flex items-center justify-center
                    text-champagne/70 hover:text-champagne hover:border-champagne transition-all"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {columns.map((col) => (
            <div key={col.title}>
              <h4 className="font-sans text-xs font-semibold tracking-wider uppercase text-champagne mb-4">
                {col.title}
              </h4>
              <ul className="space-y-2.5">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <button
                      onClick={() => navigate(link.path)}
                      className="text-sm text-porcelain/60 hover:text-champagne transition-colors text-left"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Contact bar */}
        <div className="mt-12 pt-8 border-t border-champagne/15 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-porcelain/50">
            <span className="flex items-center gap-2"><Mail size={14} /> care@moderone.com</span>
            <span className="flex items-center gap-2"><Phone size={14} /> +1 (800) 555-0190</span>
            <span className="flex items-center gap-2"><MapPin size={14} /> New York · Paris · Dubai</span>
          </div>
          <p className="text-xs text-porcelain/40">© 2026 MODER ONE. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
