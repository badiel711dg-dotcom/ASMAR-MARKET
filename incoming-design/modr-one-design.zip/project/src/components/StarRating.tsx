import { Star } from 'lucide-react';

type Props = {
  rating: number;
  count?: number;
  size?: number;
  showValue?: boolean;
};

export function StarRating({ rating, count, size = 14, showValue = true }: Props) {
  return (
    <div className="flex items-center gap-1.5">
      <div className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            size={size}
            className={
              star <= Math.round(rating)
                ? 'fill-champagne text-champagne'
                : 'fill-transparent text-champagne/30'
            }
          />
        ))}
      </div>
      {showValue && (
        <span className="text-xs text-taupe font-medium">
          {rating > 0 ? rating.toFixed(1) : '—'}
          {count !== undefined && count > 0 && ` (${count})`}
        </span>
      )}
    </div>
  );
}
