import { useRouter } from '@/context/RouterContext';
import type { Category } from '@/types';

type Props = {
  category: Category;
};

export function CategoryCard({ category }: Props) {
  const { navigate } = useRouter();

  return (
    <div
      onClick={() => navigate(`/categories/${category.slug}`)}
      className="group cursor-pointer relative aspect-square rounded-xl overflow-hidden card-luxury hover:shadow-luxury-md"
    >
      {category.image_url ? (
        <img
          src={category.image_url}
          alt={category.name}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
      ) : (
        <div className="w-full h-full bg-gradient-to-br from-dusty-rose/40 to-champagne/20" />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-deep-brown/70 via-deep-brown/10 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <h3 className="font-serif text-lg font-medium text-porcelain">{category.name}</h3>
        {category.name_ar && (
          <p className="text-sm text-porcelain/70 font-arabic" dir="rtl">{category.name_ar}</p>
        )}
      </div>
    </div>
  );
}
