import { useState, useEffect } from 'react';
import { AuthProvider } from '@/context/AuthContext';
import { ShopProvider } from '@/context/ShopContext';
import { RouterProvider, useRouter, parseRoute } from '@/context/RouterContext';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { CartDrawer } from '@/components/CartDrawer';
import { MobileNav } from '@/components/MobileNav';
import { WelcomeScreen, hasSeenWelcome } from '@/components/WelcomeScreen';
import { HomePage } from '@/pages/HomePage';
import { ProductDetailPage } from '@/pages/ProductDetailPage';
import { CategoryPage } from '@/pages/CategoryPage';
import { StorePage } from '@/pages/StorePage';
import { CartPage, CheckoutPage } from '@/pages/CartCheckoutPages';
import { AuthPage } from '@/pages/AuthPage';
import { WishlistPage } from '@/pages/WishlistPage';
import { AccountPage } from '@/pages/AccountPage';

function AppContent() {
  const { route } = useRouter();
  const { name, params } = parseRoute(route.path);
  const [showWelcome, setShowWelcome] = useState(false);

  useEffect(() => {
    if (!hasSeenWelcome()) {
      setShowWelcome(true);
    }
  }, []);

  const renderPage = () => {
    switch (name) {
      case 'home': return <HomePage />;
      case 'product': return <ProductDetailPage productId={params.id} />;
      case 'category': return <CategoryPage categorySlug={params.slug} />;
      case 'categories': return <CategoryPage />;
      case 'search': return <CategoryPage searchMode />;
      case 'store': return <StorePage slug={params.slug} />;
      case 'stores': return <StorePage />;
      case 'cart': return <CartPage />;
      case 'checkout': return <CheckoutPage />;
      case 'signin': return <AuthPage mode="signin" />;
      case 'signup': return <AuthPage mode="signup" />;
      case 'wishlist': return <WishlistPage />;
      case 'account': return <AccountPage />;
      case 'dashboard': return <AccountPage />;
      default: return <HomePage />;
    }
  };

  const hideChrome = name === 'signin' || name === 'signup';

  if (showWelcome) {
    return <WelcomeScreen onEnter={() => setShowWelcome(false)} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-ivory">
      {!hideChrome && <Header />}
      <main className="flex-1">
        {renderPage()}
      </main>
      {!hideChrome && <Footer />}
      {!hideChrome && <CartDrawer />}
      {!hideChrome && <MobileNav />}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <ShopProvider>
        <RouterProvider>
          <AppContent />
        </RouterProvider>
      </ShopProvider>
    </AuthProvider>
  );
}

export default App;
