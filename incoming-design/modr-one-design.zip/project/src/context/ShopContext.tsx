import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './AuthContext';
import type { CartItem, WishlistItem } from '@/types';

type ShopContextType = {
  cartItems: CartItem[];
  wishlistItems: WishlistItem[];
  cartCount: number;
  wishlistCount: number;
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  addToCart: (productId: string, quantity?: number, variant?: Record<string, string> | null) => Promise<void>;
  updateCartQty: (cartItemId: string, quantity: number) => Promise<void>;
  removeFromCart: (cartItemId: string) => Promise<void>;
  toggleWishlist: (productId: string) => Promise<void>;
  isInWishlist: (productId: string) => boolean;
  refreshCart: () => Promise<void>;
  refreshWishlist: () => Promise<void>;
};

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export function ShopProvider({ children }: { children: ReactNode }) {
  const { session } = useAuth();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);

  const refreshCart = useCallback(async () => {
    if (!session?.user) {
      setCartItems([]);
      return;
    }
    const { data } = await supabase
      .from('cart_items')
      .select('*, products(*)')
      .eq('user_id', session.user.id);
    setCartItems((data as CartItem[]) ?? []);
  }, [session]);

  const refreshWishlist = useCallback(async () => {
    if (!session?.user) {
      setWishlistItems([]);
      return;
    }
    const { data } = await supabase
      .from('wishlist_items')
      .select('*, products(*)')
      .eq('user_id', session.user.id);
    setWishlistItems((data as WishlistItem[]) ?? []);
  }, [session]);

  useEffect(() => {
    refreshCart();
    refreshWishlist();
  }, [refreshCart, refreshWishlist]);

  const addToCart = async (productId: string, quantity = 1, variant: Record<string, string> | null = null) => {
    if (!session?.user) return;
    const existing = cartItems.find(
      (item) => item.product_id === productId &&
      JSON.stringify(item.variant) === JSON.stringify(variant)
    );
    if (existing) {
      await updateCartQty(existing.id, existing.quantity + quantity);
    } else {
      await supabase.from('cart_items').insert({
        user_id: session.user.id,
        product_id: productId,
        quantity,
        variant,
      });
      await refreshCart();
    }
    setCartOpen(true);
  };

  const updateCartQty = async (cartItemId: string, quantity: number) => {
    if (quantity <= 0) {
      await removeFromCart(cartItemId);
      return;
    }
    await supabase.from('cart_items').update({ quantity }).eq('id', cartItemId);
    await refreshCart();
  };

  const removeFromCart = async (cartItemId: string) => {
    await supabase.from('cart_items').delete().eq('id', cartItemId);
    await refreshCart();
  };

  const toggleWishlist = async (productId: string) => {
    if (!session?.user) return;
    const existing = wishlistItems.find((item) => item.product_id === productId);
    if (existing) {
      await supabase.from('wishlist_items').delete().eq('id', existing.id);
    } else {
      await supabase.from('wishlist_items').insert({
        user_id: session.user.id,
        product_id: productId,
      });
    }
    await refreshWishlist();
  };

  const isInWishlist = (productId: string) => {
    return wishlistItems.some((item) => item.product_id === productId);
  };

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <ShopContext.Provider value={{
      cartItems, wishlistItems, cartCount, wishlistCount: wishlistItems.length,
      cartOpen, setCartOpen, addToCart, updateCartQty, removeFromCart,
      toggleWishlist, isInWishlist, refreshCart, refreshWishlist,
    }}>
      {children}
    </ShopContext.Provider>
  );
}

export function useShop() {
  const ctx = useContext(ShopContext);
  if (!ctx) throw new Error('useShop must be used within ShopProvider');
  return ctx;
}
