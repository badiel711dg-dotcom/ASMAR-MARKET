import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

type Route = {
  path: string;
  params: Record<string, string>;
};

type RouterContextType = {
  route: Route;
  navigate: (path: string) => void;
};

const RouterContext = createContext<RouterContextType | undefined>(undefined);

function parsePath(): Route {
  const hash = window.location.hash.replace(/^#/, '') || '/';
  const parts = hash.split('/').filter(Boolean);
  return { path: hash, params: {} };
}

export function RouterProvider({ children }: { children: ReactNode }) {
  const [route, setRoute] = useState<Route>(parsePath());

  useEffect(() => {
    const onHashChange = () => {
      setRoute(parsePath());
      window.scrollTo(0, 0);
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = (path: string) => {
    window.location.hash = path;
  };

  return (
    <RouterContext.Provider value={{ route, navigate }}>
      {children}
    </RouterContext.Provider>
  );
}

export function useRouter() {
  const ctx = useContext(RouterContext);
  if (!ctx) throw new Error('useRouter must be used within RouterProvider');
  return ctx;
}

export function parseRoute(path: string): { name: string; params: Record<string, string> } {
  const parts = path.split('/').filter(Boolean);
  if (parts.length === 0) return { name: 'home', params: {} };
  if (parts[0] === 'products' && parts[1]) return { name: 'product', params: { id: parts[1] } };
  if (parts[0] === 'categories' && parts[1]) return { name: 'category', params: { slug: parts[1] } };
  if (parts[0] === 'stores' && parts[1]) return { name: 'store', params: { slug: parts[1] } };
  if (parts[0] === 'search') return { name: 'search', params: {} };
  if (parts[0] === 'cart') return { name: 'cart', params: {} };
  if (parts[0] === 'checkout') return { name: 'checkout', params: {} };
  if (parts[0] === 'wishlist') return { name: 'wishlist', params: {} };
  if (parts[0] === 'account') return { name: 'account', params: {} };
  if (parts[0] === 'signin') return { name: 'signin', params: {} };
  if (parts[0] === 'signup') return { name: 'signup', params: {} };
  if (parts[0] === 'dashboard') return { name: 'dashboard', params: {} };
  if (parts[0] === 'stores') return { name: 'stores', params: {} };
  if (parts[0] === 'categories') return { name: 'categories', params: {} };
  return { name: 'home', params: {} };
}
